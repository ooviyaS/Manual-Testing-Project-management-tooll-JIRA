import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DatePickerAutomation {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://jqueryui.com/datepicker/");
        driver.switchTo().frame(driver.findElement(By.className("demo-frame")));

        WebElement dateInput = driver.findElement(By.id("datepicker"));
        dateInput.click();

        driver.findElement(By.className("ui-datepicker-next")).click();
        driver.findElement(By.xpath("//a[text()='22']")).click();

        String selectedDate = dateInput.getAttribute("value");
        System.out.println("Selected Date: " + selectedDate);

        driver.quit();
    }
}