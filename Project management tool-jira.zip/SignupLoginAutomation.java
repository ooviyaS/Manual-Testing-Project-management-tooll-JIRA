import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SignupLoginAutomation {
    public static void main(String[] args) throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        driver.get("https://www.guvi.in/");

        driver.findElement(By.linkText("Signup")).click();
        Thread.sleep(3000);

        driver.findElement(By.id("name")).sendKeys("Test User");
        driver.findElement(By.id("email")).sendKeys("testuser1234@example.com");
        driver.findElement(By.id("password")).sendKeys("Test@123");
        driver.findElement(By.id("mobile")).sendKeys("9999999999");

        driver.findElement(By.id("signup-btn")).click();
        Thread.sleep(5000);

        driver.findElement(By.linkText("Login")).click();
        Thread.sleep(3000);

        driver.findElement(By.id("email")).sendKeys("testuser1234@example.com");
        driver.findElement(By.id("password")).sendKeys("Test@123");

        driver.findElement(By.id("login-btn")).click();
        Thread.sleep(5000);

        System.out.println("Signup and Login flow executed successfully.");
        driver.quit();
    }
}